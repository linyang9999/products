﻿namespace CSharpDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnVersion = new System.Windows.Forms.Button();
            this.editComPort = new System.Windows.Forms.TextBox();
            this.editCardId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.editText = new System.Windows.Forms.TextBox();
            this.btnTTS = new System.Windows.Forms.Button();
            this.btnSendText = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(22, 77);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(67, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "串口名称";
            // 
            // btnVersion
            // 
            this.btnVersion.Location = new System.Drawing.Point(359, 36);
            this.btnVersion.Name = "btnVersion";
            this.btnVersion.Size = new System.Drawing.Size(153, 27);
            this.btnVersion.TabIndex = 1;
            this.btnVersion.Text = "查询DLL版本号";
            this.btnVersion.UseVisualStyleBackColor = true;
            this.btnVersion.Click += new System.EventHandler(this.btnVersion_Click);
            // 
            // editComPort
            // 
            this.editComPort.Location = new System.Drawing.Point(25, 95);
            this.editComPort.Name = "editComPort";
            this.editComPort.Size = new System.Drawing.Size(100, 25);
            this.editComPort.TabIndex = 2;
            this.editComPort.Text = "COM1";
            // 
            // editCardId
            // 
            this.editCardId.Location = new System.Drawing.Point(156, 95);
            this.editCardId.Name = "editCardId";
            this.editCardId.Size = new System.Drawing.Size(100, 25);
            this.editCardId.TabIndex = 4;
            this.editCardId.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(153, 77);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "卡号";
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(302, 95);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(96, 27);
            this.btnOpen.TabIndex = 5;
            this.btnOpen.Text = "打开串口";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(416, 95);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(96, 27);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "关闭串口";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // editText
            // 
            this.editText.Location = new System.Drawing.Point(23, 151);
            this.editText.Multiline = true;
            this.editText.Name = "editText";
            this.editText.Size = new System.Drawing.Size(489, 98);
            this.editText.TabIndex = 7;
            this.editText.Text = "[v1]欢迎光临";
            // 
            // btnTTS
            // 
            this.btnTTS.Location = new System.Drawing.Point(395, 265);
            this.btnTTS.Name = "btnTTS";
            this.btnTTS.Size = new System.Drawing.Size(117, 27);
            this.btnTTS.TabIndex = 9;
            this.btnTTS.Text = "语音播报";
            this.btnTTS.UseVisualStyleBackColor = true;
            this.btnTTS.Click += new System.EventHandler(this.btnTTS_Click);
            // 
            // btnSendText
            // 
            this.btnSendText.Location = new System.Drawing.Point(255, 265);
            this.btnSendText.Name = "btnSendText";
            this.btnSendText.Size = new System.Drawing.Size(117, 27);
            this.btnSendText.TabIndex = 8;
            this.btnSendText.Text = "发送到显示屏";
            this.btnSendText.UseVisualStyleBackColor = true;
            this.btnSendText.Click += new System.EventHandler(this.btnSendText_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(533, 312);
            this.Controls.Add(this.btnTTS);
            this.Controls.Add(this.btnSendText);
            this.Controls.Add(this.editText);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.editCardId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.editComPort);
            this.Controls.Add(this.btnVersion);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "C#Demo for SNXT.dll";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVersion;
        private System.Windows.Forms.TextBox editComPort;
        private System.Windows.Forms.TextBox editCardId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox editText;
        private System.Windows.Forms.Button btnTTS;
        private System.Windows.Forms.Button btnSendText;
    }
}

