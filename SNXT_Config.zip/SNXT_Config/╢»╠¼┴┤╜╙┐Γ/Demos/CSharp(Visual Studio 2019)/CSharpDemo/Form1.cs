﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;   //使用DLL要加入此行
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

//SNXT.DLL操作步骤
//1. 调用OpenComPort函数打开串口，并保存返回的串口句柄
//2. 调用SendText StartTTS等功能函数
//3. 调用CloseComport函数关闭串口
namespace CSharpDemo
{
    public partial class Form1 : Form
    {
        const UInt32 INVALID_HANDLE_VALUE = 0xFFFFFFFF;
        public UInt32 m_hComPort = INVALID_HANDLE_VALUE;
        public class snxt
        {
            [DllImport("SNXT.dll", EntryPoint = "GetDllVersion", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern Int32 GetDllVersion();

            [DllImport("SNXT.dll", EntryPoint = "OpenComPort", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern UInt32 OpenComPort(char[] szComPort, Int32 nBaudrate);

            [DllImport("SNXT.dll", EntryPoint = "CloseComPort", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern void CloseComPort(UInt32 hComPort);

            [DllImport("SNXT.dll", EntryPoint = "SendText", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern Int32 SendText(UInt32 hComPort, Int32 nCardId, char[] szText);

            [DllImport("SNXT.dll", EntryPoint = "StartTTS", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern Int32 StartTTS(UInt32 hComPort, Int32 nCardId, char[] szText);
        }
        public Form1()
        {
            InitializeComponent();
        }

        //查询DLL软件版本号
        private void btnVersion_Click(object sender, EventArgs e)
        {
            Int32 nVersion = snxt.GetDllVersion();
            MessageBox.Show("SNXT.dll版本：" + nVersion / 256 + "." + nVersion % 256);
        }

        //打开串口, 波特率9600，8位数据，1个停止位，无校验
        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (m_hComPort != INVALID_HANDLE_VALUE)
            {
                MessageBox.Show("无效操作。串口已打开");
                return;
            }

            //注意调用OpenComPort时传入的串口名称为wchar_t*类型的双字节Unicode字符串
            m_hComPort = snxt.OpenComPort(editComPort.Text.ToCharArray(), 9600);
            if (m_hComPort != INVALID_HANDLE_VALUE)
                MessageBox.Show("串口打开成功");
            else
                MessageBox.Show("串口打开失败。请检查串口名称是否正确及其它程序是否正在使用该串口。");
        }

        //关闭串口
        private void btnClose_Click(object sender, EventArgs e)
        {
            if (m_hComPort != INVALID_HANDLE_VALUE)
            {
                snxt.CloseComPort(m_hComPort);
                m_hComPort = INVALID_HANDLE_VALUE;
                MessageBox.Show("串口关闭成功");
            }
            else
                MessageBox.Show("无效操作，串口已经关闭");
        }

        //发送文字到显示屏
        private void btnSendText_Click(object sender, EventArgs e)
        {
            if (m_hComPort == INVALID_HANDLE_VALUE)
            {
                MessageBox.Show("请在操作前先打开串口");
                return;
            }

            if (snxt.SendText(m_hComPort, Convert.ToInt32(editCardId.Text), editText.Text.ToCharArray()) != 0)
                MessageBox.Show("显示文字命令发送失败");
            else
                MessageBox.Show("显示文字命令发送成功");
        }

        //语音播报
        private void btnTTS_Click(object sender, EventArgs e)
        {
            if (m_hComPort == INVALID_HANDLE_VALUE)
            {
                MessageBox.Show("请在操作前先打开串口");
                return;
            }

            if (snxt.StartTTS(m_hComPort, Convert.ToInt32(editCardId.Text), editText.Text.ToCharArray()) != 0)
                MessageBox.Show("语音播报命令发送失败");
            else
                MessageBox.Show("语音播报命令发送成功");
        }

        //程序退出前关闭串口
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (m_hComPort != INVALID_HANDLE_VALUE)
                snxt.CloseComPort(m_hComPort);
        }
    }
}
