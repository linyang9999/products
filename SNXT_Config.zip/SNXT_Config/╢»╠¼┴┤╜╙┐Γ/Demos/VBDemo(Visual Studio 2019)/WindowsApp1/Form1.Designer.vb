﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form 重写 Dispose，以清理组件列表。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows 窗体设计器所必需的
    Private components As System.ComponentModel.IContainer

    '注意: 以下过程是 Windows 窗体设计器所必需的
    '可以使用 Windows 窗体设计器修改它。  
    '不要使用代码编辑器修改它。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnVersion = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.editComPortName = New System.Windows.Forms.TextBox()
        Me.editCardId = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.btnOpen = New System.Windows.Forms.Button()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.editText = New System.Windows.Forms.TextBox()
        Me.btnTTS = New System.Windows.Forms.Button()
        Me.btnSendText = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'btnVersion
        '
        Me.btnVersion.Location = New System.Drawing.Point(352, 36)
        Me.btnVersion.Name = "btnVersion"
        Me.btnVersion.Size = New System.Drawing.Size(130, 27)
        Me.btnVersion.TabIndex = 0
        Me.btnVersion.Text = "查询DLL版本"
        Me.btnVersion.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(23, 72)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(67, 15)
        Me.Label1.TabIndex = 1
        Me.Label1.Text = "串口名称"
        '
        'editComPortName
        '
        Me.editComPortName.Location = New System.Drawing.Point(26, 90)
        Me.editComPortName.Name = "editComPortName"
        Me.editComPortName.Size = New System.Drawing.Size(85, 25)
        Me.editComPortName.TabIndex = 2
        Me.editComPortName.Text = "COM1"
        '
        'editCardId
        '
        Me.editCardId.Location = New System.Drawing.Point(129, 90)
        Me.editCardId.Name = "editCardId"
        Me.editCardId.Size = New System.Drawing.Size(85, 25)
        Me.editCardId.TabIndex = 4
        Me.editCardId.Text = "1"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(126, 72)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(37, 15)
        Me.Label2.TabIndex = 3
        Me.Label2.Text = "卡号"
        '
        'btnOpen
        '
        Me.btnOpen.Location = New System.Drawing.Point(241, 90)
        Me.btnOpen.Name = "btnOpen"
        Me.btnOpen.Size = New System.Drawing.Size(111, 27)
        Me.btnOpen.TabIndex = 5
        Me.btnOpen.Text = "打开串口"
        Me.btnOpen.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(371, 88)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(111, 27)
        Me.btnClose.TabIndex = 6
        Me.btnClose.Text = "关闭串口"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'editText
        '
        Me.editText.Location = New System.Drawing.Point(26, 145)
        Me.editText.Multiline = True
        Me.editText.Name = "editText"
        Me.editText.Size = New System.Drawing.Size(455, 116)
        Me.editText.TabIndex = 7
        Me.editText.Text = "[v1]欢迎光临"
        '
        'btnTTS
        '
        Me.btnTTS.Location = New System.Drawing.Point(371, 283)
        Me.btnTTS.Name = "btnTTS"
        Me.btnTTS.Size = New System.Drawing.Size(111, 27)
        Me.btnTTS.TabIndex = 9
        Me.btnTTS.Text = "语音播报"
        Me.btnTTS.UseVisualStyleBackColor = True
        '
        'btnSendText
        '
        Me.btnSendText.Location = New System.Drawing.Point(241, 285)
        Me.btnSendText.Name = "btnSendText"
        Me.btnSendText.Size = New System.Drawing.Size(111, 27)
        Me.btnSendText.TabIndex = 8
        Me.btnSendText.Text = "发送到显示屏"
        Me.btnSendText.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(506, 328)
        Me.Controls.Add(Me.btnTTS)
        Me.Controls.Add(Me.btnSendText)
        Me.Controls.Add(Me.editText)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.btnOpen)
        Me.Controls.Add(Me.editCardId)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.editComPortName)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnVersion)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "Form1"
        Me.Text = "VB Demo for SNXT.dll"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btnVersion As Button
    Friend WithEvents Label1 As Label
    Friend WithEvents editComPortName As TextBox
    Friend WithEvents editCardId As TextBox
    Friend WithEvents Label2 As Label
    Friend WithEvents btnOpen As Button
    Friend WithEvents btnClose As Button
    Friend WithEvents editText As TextBox
    Friend WithEvents btnTTS As Button
    Friend WithEvents btnSendText As Button
End Class
