﻿Public Class Form1
    Public Const INVALID_HANDLE_VALUE = -1

    '串口句柄
    Public hComPort As Integer

    'DLL函数定义
    Public Declare Function GetDllVersion Lib "SNXT.dll" () As Integer
    Public Declare Unicode Function OpenComPort Lib "SNXT.dll" (ByVal sComPortName As String, ByVal nBaudrate As Integer) As Integer
    Public Declare Sub CloseComPort Lib "SNXT.dll" (ByVal hComPort As Integer)
    Public Declare Unicode Function SendText Lib "SNXT.dll" (ByVal hComPort As Integer, ByVal nCardId As Integer, ByVal sText As String) As Integer
    Public Declare Unicode Function StartTTS Lib "SNXT.dll" (ByVal hComPort As Integer, ByVal nCardId As Integer, ByVal sText As String) As Integer

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        '在程序开始运行时初始化hComPort
        hComPort = INVALID_HANDLE_VALUE
    End Sub

    '查询DLL软件版本号
    Private Sub btnVersion_Click(sender As Object, e As EventArgs) Handles btnVersion.Click
        Dim nVersion As Integer

        nVersion = GetDllVersion
        MsgBox("SNXT.dll版本：" + Str(nVersion \ 256） + "." + Str(nVersion Mod 256))
    End Sub

    '打开串口, 波特率9600，8位数据，1个停止位，无校验
    Private Sub btnOpen_Click(sender As Object, e As EventArgs) Handles btnOpen.Click
        If hComPort <> INVALID_HANDLE_VALUE Then
            MsgBox("无效操作。串口已打开")
            Exit Sub
        End If

        hComPort = OpenComPort(editComPortName.Text, 9600)

        If hComPort <> INVALID_HANDLE_VALUE Then
            MsgBox("串口打开成功")
        Else
            MsgBox("串口打开失败。请检查串口名称是否正确及其它程序是否正在使用该串口。")
        End If
    End Sub

    '关闭串口
    Private Sub btnClose_Click(sender As Object, e As EventArgs) Handles btnClose.Click
        If hComPort = INVALID_HANDLE_VALUE Then
            MsgBox("无效操作。串口已关闭")
            Exit Sub
        End If

        CloseComPort(hComPort)
        hComPort = INVALID_HANDLE_VALUE
        MsgBox("串口关闭成功")
    End Sub

    '发送文字到显示屏
    Private Sub btnSendText_Click(sender As Object, e As EventArgs) Handles btnSendText.Click
        If hComPort = INVALID_HANDLE_VALUE Then
            MsgBox("请在操作前先打开串口")
            Exit Sub
        End If

        If SendText(hComPort, Int(editCardId.Text), editText.Text) <> 0 Then
            MsgBox("显示文字命令发送失败")
        Else
            MsgBox("显示文字命令发送成功")
        End If
    End Sub

    '语音播报
    Private Sub btnTTS_Click(sender As Object, e As EventArgs) Handles btnTTS.Click
        If hComPort = INVALID_HANDLE_VALUE Then
            MsgBox("请在操作前先打开串口")
            Exit Sub
        End If

        If StartTTS(hComPort, Int(editCardId.Text), editText.Text) <> 0 Then
            MsgBox("语音播报命令发送失败")
        Else
            MsgBox("语音播报命令发送成功")
        End If
    End Sub

    '程序退出时关闭串口
    Private Sub Form1_FormClosed(sender As Object, e As FormClosedEventArgs) Handles MyBase.FormClosed
        If hComPort <> INVALID_HANDLE_VALUE Then
            CloseComPort(hComPort)
        End If
    End Sub
End Class
