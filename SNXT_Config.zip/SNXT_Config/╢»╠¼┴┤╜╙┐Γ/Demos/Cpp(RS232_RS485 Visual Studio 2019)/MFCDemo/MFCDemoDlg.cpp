﻿
// MFCDemoDlg.cpp: 实现文件
//

#include "pch.h"
#include "framework.h"
#include "MFCDemo.h"
#include "MFCDemoDlg.h"
#include "afxdialogex.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#endif


// 用于应用程序“关于”菜单项的 CAboutDlg 对话框

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_ABOUTBOX };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV 支持

// 实现
protected:
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(IDD_ABOUTBOX)
{
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
END_MESSAGE_MAP()


// CMFCDemoDlg 对话框



CMFCDemoDlg::CMFCDemoDlg(CWnd* pParent /*=nullptr*/)
	: CDialog(IDD_MFCDEMO_DIALOG, pParent)
	, m_sComPort(_T("COM1"))
	, m_nCardId(1)
	, m_sText(_T("[v1]欢迎光临"))
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void CMFCDemoDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_EDIT_COMPORT, m_sComPort);
	DDV_MaxChars(pDX, m_sComPort, 16);
	DDX_Text(pDX, IDC_EDIT_CARDID, m_nCardId);
	DDV_MinMaxInt(pDX, m_nCardId, 0, 4095);
	DDX_Text(pDX, IDC_EDIT_TEXT, m_sText);
	DDV_MaxChars(pDX, m_sText, 512);
}

BEGIN_MESSAGE_MAP(CMFCDemoDlg, CDialog)
	ON_WM_SYSCOMMAND()
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDFREE, &CMFCDemoDlg::OnBnClickedFree)
	ON_BN_CLICKED(IDLoad, &CMFCDemoDlg::OnBnClickedLoad)
	ON_BN_CLICKED(IDVERSION, &CMFCDemoDlg::OnBnClickedVersion)
	ON_BN_CLICKED(IDOPENCOMPORT, &CMFCDemoDlg::OnBnClickedOpencomport)
	ON_BN_CLICKED(IDCLOSECOMPORT, &CMFCDemoDlg::OnBnClickedClosecomport)
	ON_BN_CLICKED(ID_DISPLAY, &CMFCDemoDlg::OnBnClickedDisplay)
	ON_BN_CLICKED(ID_TTS, &CMFCDemoDlg::OnBnClickedTts)
	ON_WM_DESTROY()
END_MESSAGE_MAP()


// CMFCDemoDlg 消息处理程序

BOOL CMFCDemoDlg::OnInitDialog()
{
	CDialog::OnInitDialog();

	// 将“关于...”菜单项添加到系统菜单中。

	// IDM_ABOUTBOX 必须在系统命令范围内。
	ASSERT((IDM_ABOUTBOX & 0xFFF0) == IDM_ABOUTBOX);
	ASSERT(IDM_ABOUTBOX < 0xF000);

	CMenu* pSysMenu = GetSystemMenu(FALSE);
	if (pSysMenu != nullptr)
	{
		BOOL bNameValid;
		CString strAboutMenu;
		bNameValid = strAboutMenu.LoadString(IDS_ABOUTBOX);
		ASSERT(bNameValid);
		if (!strAboutMenu.IsEmpty())
		{
			pSysMenu->AppendMenu(MF_SEPARATOR);
			pSysMenu->AppendMenu(MF_STRING, IDM_ABOUTBOX, strAboutMenu);
		}
	}

	// 设置此对话框的图标。  当应用程序主窗口不是对话框时，框架将自动
	//  执行此操作
	SetIcon(m_hIcon, TRUE);			// 设置大图标
	SetIcon(m_hIcon, FALSE);		// 设置小图标

	// TODO: 在此添加额外的初始化代码
	//初始化 SNXT.dll 实例句柄
	hDll = NULL;
	//初始化串口句柄
	hComPort = INVALID_HANDLE_VALUE;

	return TRUE;  // 除非将焦点设置到控件，否则返回 TRUE
}

void CMFCDemoDlg::OnSysCommand(UINT nID, LPARAM lParam)
{
	if ((nID & 0xFFF0) == IDM_ABOUTBOX)
	{
		CAboutDlg dlgAbout;
		dlgAbout.DoModal();
	}
	else
	{
		CDialog::OnSysCommand(nID, lParam);
	}
}

// 如果向对话框添加最小化按钮，则需要下面的代码
//  来绘制该图标。  对于使用文档/视图模型的 MFC 应用程序，
//  这将由框架自动完成。

void CMFCDemoDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // 用于绘制的设备上下文

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// 使图标在工作区矩形中居中
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// 绘制图标
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialog::OnPaint();
	}
}

//当用户拖动最小化窗口时系统调用此函数取得光标
//显示。
HCURSOR CMFCDemoDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}

//加载DLL，实际使用时可在程序初始化时处理
void CMFCDemoDlg::OnBnClickedLoad()
{
	if (hDll != NULL)
	{
		AfxMessageBox(_T("无效操作，SNXT.dll已经加载"));
		return;
	}

	//装入DLL
	hDll = LoadLibrary(_T("SNXT.dll"));
	if (hDll != NULL)
	{
		AfxMessageBox(_T("SNXT.dll加载成功"));
		//如果装入成功，获取DLL内的函数入口地址
		GetDllVersion = (GetDllVersion_P)GetProcAddress(hDll, "GetDllVersion");
		OpenComPort = (OpenComPort_P)GetProcAddress(hDll, "OpenComPort");
		CloseComPort = (CloseComPort_P)GetProcAddress(hDll, "CloseComPort");
		SendText = (SendText_P)GetProcAddress(hDll, "SendText");
		StartTTS = (StartTTS_P)GetProcAddress(hDll, "StartTTS");
	}
	else
	{
		AfxMessageBox(_T("SNXT.dll加载失败"));
	}
}

//释放DLL. 实际使用时可在退出程序前调用
void CMFCDemoDlg::OnBnClickedFree()
{
	if (hComPort != INVALID_HANDLE_VALUE)
	{
		AfxMessageBox(_T("请在操作前先关闭串口"));
		return;
	}

	if (hDll)
	{
		FreeLibrary(hDll);
		hDll = NULL;
		AfxMessageBox(_T("释放SNXT.dll成功"));
	}
	else
	{
		AfxMessageBox(_T("无效操作，SNXT.dll已释放"));
	}
}

//查询DLL软件版本号
void CMFCDemoDlg::OnBnClickedVersion()
{
	if (hDll == NULL)
	{
		AfxMessageBox(_T("请在操作前先加载SNXT.dll"));
		return;
	}

	int nVersion = GetDllVersion();
	CString s;
	s.Format(_T("SNXT.dll 版本号：%d.%d"), nVersion / 256, nVersion % 256);

	AfxMessageBox(s);
}

//打开串口, 波特率9600，8位数据，1个停止位，无校验
void CMFCDemoDlg::OnBnClickedOpencomport()
{
	UpdateData();

	if (hDll == NULL)
	{
		AfxMessageBox(_T("请在操作前先加载SNXT.dll"));
		return;
	}

	if (hComPort != INVALID_HANDLE_VALUE)
	{
		AfxMessageBox(_T("无效操作。串口已打开"));
		return;
	}

	//注意调用OpenComPort时传入的串口名称为wchar_t*类型的双字节Unicode字符串
	hComPort = OpenComPort(LPCWSTR(m_sComPort), 9600);
	if (hComPort != INVALID_HANDLE_VALUE)
		AfxMessageBox(_T("串口打开成功"));
	else
		AfxMessageBox(_T("串口打开失败。请检查串口名称是否正确及其它程序是否正在使用该串口。"));
}

//关闭串口
void CMFCDemoDlg::OnBnClickedClosecomport()
{
	if (hDll == NULL)
	{
		AfxMessageBox(_T("请在操作前先加载SNXT.dll"));
		return;
	}

	if (hComPort != INVALID_HANDLE_VALUE)
	{
		CloseComPort(hComPort);
		hComPort = INVALID_HANDLE_VALUE;
		AfxMessageBox(_T("串口关闭成功"));
	}
	else
		AfxMessageBox(_T("无效操作，串口已经关闭"));
}

//发送文字到显示屏
void CMFCDemoDlg::OnBnClickedDisplay()
{
	UpdateData();

	if (hDll == NULL)
	{
		AfxMessageBox(_T("请在操作前先加载SNXT.dll"));
		return;
	}

	if (hComPort == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox(_T("请在操作前先打开串口"));
		return;
	}

	//注意SendText参数中的显示字符串为wchar_t类型的Unicode字符串
	if (SendText(hComPort, m_nCardId, LPCWSTR(m_sText)))
		AfxMessageBox(_T("显示文字命令发送失败"));
	else
		AfxMessageBox(_T("显示文字命令发送成功"));
}

//语音播报
void CMFCDemoDlg::OnBnClickedTts()
{
	UpdateData();

	if (hDll == NULL)
	{
		AfxMessageBox(_T("请在操作前先加载SNXT.dll"));
		return;
	}

	if (hComPort == INVALID_HANDLE_VALUE)
	{
		AfxMessageBox(_T("请在操作前先打开串口"));
		return;
	}

	//注意StartTTS参数中的显示字符串为wchar_t类型的Unicode字符串
	if (StartTTS(hComPort, m_nCardId, LPCWSTR(m_sText)))
		AfxMessageBox(_T("语音播报命令发送失败"));
	else
		AfxMessageBox(_T("语音播报命令发送成功"));
}

//程序退出前关闭串口并释放DLL
void CMFCDemoDlg::OnDestroy()
{
	CDialog::OnDestroy();

	if (hComPort != INVALID_HANDLE_VALUE)
		CloseComPort(hComPort);

	if (hDll)
		FreeLibrary(hDll);
}
