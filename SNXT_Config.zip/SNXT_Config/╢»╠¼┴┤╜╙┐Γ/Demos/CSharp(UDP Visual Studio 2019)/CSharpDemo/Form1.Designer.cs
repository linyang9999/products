﻿namespace CSharpDemo
{
    partial class Form1
    {
        /// <summary>
        /// 必需的设计器变量。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清理所有正在使用的资源。
        /// </summary>
        /// <param name="disposing">如果应释放托管资源，为 true；否则为 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows 窗体设计器生成的代码

        /// <summary>
        /// 设计器支持所需的方法 - 不要修改
        /// 使用代码编辑器修改此方法的内容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.btnVersion = new System.Windows.Forms.Button();
            this.editLocalIp = new System.Windows.Forms.TextBox();
            this.editCardId = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.btnOpen = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.editText = new System.Windows.Forms.TextBox();
            this.btnTTS = new System.Windows.Forms.Button();
            this.btnSendText = new System.Windows.Forms.Button();
            this.editCardIp = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.editLocalPort = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.editCardPort = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(35, 80);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 15);
            this.label1.TabIndex = 0;
            this.label1.Text = "本机IP地址";
            // 
            // btnVersion
            // 
            this.btnVersion.Location = new System.Drawing.Point(372, 36);
            this.btnVersion.Name = "btnVersion";
            this.btnVersion.Size = new System.Drawing.Size(153, 27);
            this.btnVersion.TabIndex = 1;
            this.btnVersion.Text = "查询DLL版本号";
            this.btnVersion.UseVisualStyleBackColor = true;
            this.btnVersion.Click += new System.EventHandler(this.btnVersion_Click);
            // 
            // editLocalIp
            // 
            this.editLocalIp.Location = new System.Drawing.Point(38, 98);
            this.editLocalIp.Name = "editLocalIp";
            this.editLocalIp.Size = new System.Drawing.Size(135, 25);
            this.editLocalIp.TabIndex = 2;
            this.editLocalIp.Text = "192.168.1.105";
            // 
            // editCardId
            // 
            this.editCardId.Location = new System.Drawing.Point(327, 98);
            this.editCardId.Name = "editCardId";
            this.editCardId.Size = new System.Drawing.Size(100, 25);
            this.editCardId.TabIndex = 4;
            this.editCardId.Text = "1";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(324, 80);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(37, 15);
            this.label2.TabIndex = 3;
            this.label2.Text = "卡号";
            // 
            // btnOpen
            // 
            this.btnOpen.Location = new System.Drawing.Point(36, 36);
            this.btnOpen.Name = "btnOpen";
            this.btnOpen.Size = new System.Drawing.Size(119, 27);
            this.btnOpen.TabIndex = 5;
            this.btnOpen.Text = "打开网路连接";
            this.btnOpen.UseVisualStyleBackColor = true;
            this.btnOpen.Click += new System.EventHandler(this.btnOpen_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(175, 36);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(121, 27);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "关闭网路连接";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // editText
            // 
            this.editText.Location = new System.Drawing.Point(36, 201);
            this.editText.Multiline = true;
            this.editText.Name = "editText";
            this.editText.Size = new System.Drawing.Size(489, 98);
            this.editText.TabIndex = 7;
            this.editText.Text = "[v1]欢迎光临";
            // 
            // btnTTS
            // 
            this.btnTTS.Location = new System.Drawing.Point(408, 317);
            this.btnTTS.Name = "btnTTS";
            this.btnTTS.Size = new System.Drawing.Size(117, 27);
            this.btnTTS.TabIndex = 9;
            this.btnTTS.Text = "语音播报";
            this.btnTTS.UseVisualStyleBackColor = true;
            this.btnTTS.Click += new System.EventHandler(this.btnTTS_Click);
            // 
            // btnSendText
            // 
            this.btnSendText.Location = new System.Drawing.Point(268, 317);
            this.btnSendText.Name = "btnSendText";
            this.btnSendText.Size = new System.Drawing.Size(117, 27);
            this.btnSendText.TabIndex = 8;
            this.btnSendText.Text = "发送到显示屏";
            this.btnSendText.UseVisualStyleBackColor = true;
            this.btnSendText.Click += new System.EventHandler(this.btnSendText_Click);
            // 
            // editCardIp
            // 
            this.editCardIp.Location = new System.Drawing.Point(38, 159);
            this.editCardIp.Name = "editCardIp";
            this.editCardIp.Size = new System.Drawing.Size(135, 25);
            this.editCardIp.TabIndex = 11;
            this.editCardIp.Text = "192.168.1.100";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(35, 141);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(98, 15);
            this.label3.TabIndex = 10;
            this.label3.Text = "控制卡IP地址";
            // 
            // editLocalPort
            // 
            this.editLocalPort.Location = new System.Drawing.Point(196, 98);
            this.editLocalPort.Name = "editLocalPort";
            this.editLocalPort.Size = new System.Drawing.Size(100, 25);
            this.editLocalPort.TabIndex = 13;
            this.editLocalPort.Text = "3800";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(193, 80);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(82, 15);
            this.label4.TabIndex = 12;
            this.label4.Text = "本机端口号";
            // 
            // editCardPort
            // 
            this.editCardPort.Location = new System.Drawing.Point(196, 159);
            this.editCardPort.Name = "editCardPort";
            this.editCardPort.Size = new System.Drawing.Size(100, 25);
            this.editCardPort.TabIndex = 15;
            this.editCardPort.Text = "3700";
            this.editCardPort.TextChanged += new System.EventHandler(this.editCardPort_TextChanged);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(193, 141);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(97, 15);
            this.label5.TabIndex = 14;
            this.label5.Text = "控制卡端口号";
            this.label5.Click += new System.EventHandler(this.label5_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(543, 361);
            this.Controls.Add(this.editCardPort);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.editLocalPort);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.editCardIp);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.btnTTS);
            this.Controls.Add(this.btnSendText);
            this.Controls.Add(this.editText);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnOpen);
            this.Controls.Add(this.editCardId);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.editLocalIp);
            this.Controls.Add(this.btnVersion);
            this.Controls.Add(this.label1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "C#Demo for SNXT.dll";
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Form1_FormClosed);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button btnVersion;
        private System.Windows.Forms.TextBox editLocalIp;
        private System.Windows.Forms.TextBox editCardId;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btnOpen;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox editText;
        private System.Windows.Forms.Button btnTTS;
        private System.Windows.Forms.Button btnSendText;
        private System.Windows.Forms.TextBox editCardIp;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox editLocalPort;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox editCardPort;
        private System.Windows.Forms.Label label5;
    }
}

