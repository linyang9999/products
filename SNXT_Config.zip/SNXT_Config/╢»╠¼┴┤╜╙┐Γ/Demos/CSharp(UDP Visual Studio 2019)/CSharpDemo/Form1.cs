﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;   //使用DLL要加入此行
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Windows.Forms;

//SNXT.DLL操作步骤
//1. 调用OpenComPort函数打开串口，并保存返回的串口句柄
//2. 调用SendText StartTTS等功能函数
//3. 调用CloseComport函数关闭串口
namespace CSharpDemo
{
    public partial class Form1 : Form
    {
        const UInt32 INVALID_HANDLE_VALUE = 0xFFFFFFFF;
        public UInt32 m_hSocket = INVALID_HANDLE_VALUE;
        public class snxt
        {
            [DllImport("SNXT.dll", EntryPoint = "GetDllVersion", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern Int32 GetDllVersion();

            [DllImport("SNXT.dll", EntryPoint = "CreateUDPSocket", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern UInt32 CreateUDPSocket(UInt32 ulIpAddr, Int32 nPort);

            [DllImport("SNXT.dll", EntryPoint = "CloseSocket", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern void CloseSocket(UInt32 hSocket);

            [DllImport("SNXT.dll", EntryPoint = "SendText_UDP", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern Int32 SendText_UDP(UInt32 hSocket, UInt32 ulCardIpAddr, Int32 nCardSocketPort, Int32 nCardId, char[] szText);

            [DllImport("SNXT.dll", EntryPoint = "StartTTS_UDP", SetLastError = true, CharSet = CharSet.Unicode,
                ExactSpelling = true, CallingConvention = CallingConvention.Winapi)]
            public static extern Int32 StartTTS_UDP(UInt32 hSocket, UInt32 ulCardIpAddr, Int32 nCardSocketPort, Int32 nCardId, char[] szText);
        }
        public Form1()
        {
            InitializeComponent();
        }

        //查询DLL软件版本号
        private void btnVersion_Click(object sender, EventArgs e)
        {
            Int32 nVersion = snxt.GetDllVersion();
            MessageBox.Show("SNXT.dll版本：" + nVersion / 256 + "." + nVersion % 256);
        }

        //打开串口, 波特率9600，8位数据，1个停止位，无校验
        private void btnOpen_Click(object sender, EventArgs e)
        {
            if (m_hSocket != INVALID_HANDLE_VALUE)
            {
                MessageBox.Show("无效操作。已创建网络连接");
                return;
            }

            UInt32 uip = IpToInt(editLocalIp.Text);
            Int32 port = Convert.ToInt32(editLocalPort.Text);
            m_hSocket = snxt.CreateUDPSocket(uip, port);
            if (m_hSocket != INVALID_HANDLE_VALUE)
                MessageBox.Show("网络连接创建成功");
            else
                MessageBox.Show("网络连接创建失败。请检查本机IP地址和端口号是否正确。");
        }

        //关闭串口
        private void btnClose_Click(object sender, EventArgs e)
        {
            if (m_hSocket != INVALID_HANDLE_VALUE)
            {
                snxt.CloseSocket(m_hSocket);
                m_hSocket = INVALID_HANDLE_VALUE;
                MessageBox.Show("网络连接关闭成功");
            }
            else
                MessageBox.Show("无效操作，网络连接已经关闭");
        }

        //发送文字到显示屏
        private void btnSendText_Click(object sender, EventArgs e)
        {
            if (m_hSocket == INVALID_HANDLE_VALUE)
            {
                MessageBox.Show("请在操作前先创建网络连接");
                return;
            }

            UInt32 uip = IpToInt(editCardIp.Text);
            Int32 port = Convert.ToInt32(editCardPort.Text);
            if (snxt.SendText_UDP(m_hSocket, uip, port, Convert.ToInt32(editCardId.Text), editText.Text.ToCharArray()) != 0)
                MessageBox.Show("显示文字命令发送失败");
            else
                MessageBox.Show("显示文字命令发送成功");
        }

        //语音播报
        private void btnTTS_Click(object sender, EventArgs e)
        {
            if (m_hSocket == INVALID_HANDLE_VALUE)
            {
                MessageBox.Show("请在操作前先打开串口");
                return;
            }

            UInt32 uip = IpToInt(editCardIp.Text);
            Int32 port = Convert.ToInt32(editCardPort.Text);
            if (snxt.StartTTS_UDP(m_hSocket, uip, port, Convert.ToInt32(editCardId.Text), editText.Text.ToCharArray()) != 0)
                MessageBox.Show("语音播报命令发送失败");
            else
                MessageBox.Show("语音播报命令发送成功");
        }

        //程序退出前关闭串口
        private void Form1_FormClosed(object sender, FormClosedEventArgs e)
        {
            if (m_hSocket != INVALID_HANDLE_VALUE)
                snxt.CloseSocket(m_hSocket);
        }

        private UInt32 IpToInt(string ipText)
        {
            IPAddress ip = IPAddress.Parse(ipText);
            byte[] ipBytes = ip.GetAddressBytes();
            byte i = ipBytes[0];
            ipBytes[0] = ipBytes[3];
            ipBytes[3] = i;
            i = ipBytes[1];
            ipBytes[1] = ipBytes[2];
            ipBytes[2] = i;
            return BitConverter.ToUInt32(ipBytes, 0);
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void editCardPort_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

