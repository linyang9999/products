import wpf

from System.Windows import Application, Window
from ctypes import * 

class MyWindow(Window):
    def __init__(self):
        wpf.LoadComponent(self, 'WpfApplication1.xaml')

    def btnVersion_Click(self, sender, e):
        Objdll = ctypes.WinDLL('snxt.dll')
        nVersion = ObjDll.GetDllVerion
        #wx.MessageDialog()
        btnVersion.Content = nVersion

    def btnOpen_Click(self, sender, e):
        pass

if __name__ == '__main__':
    Application().Run(MyWindow())
