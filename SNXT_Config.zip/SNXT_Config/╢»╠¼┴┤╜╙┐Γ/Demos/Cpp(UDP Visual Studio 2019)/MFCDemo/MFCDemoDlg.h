﻿
// MFCDemoDlg.h: 头文件
//

#pragma once
//SNXT.DLL操作步骤
//1. 在程序启动后装入SNXT.DLL,并获取其中的函数地址
//2. 调用OpenComPort函数打开串口，并保存返回的串口句柄
//3. 调用SendText StartTTS等功能函数
//4. 调用CloseComport函数关闭串口
//5. 释放SNXT.DLL

//SNXT.DLL内的函数原型定义
typedef int(WINAPI* GetDllVersion_P)(void);
typedef SOCKET(WINAPI* CreateUDPSocket_P)(DWORD ulHostIpAddr, int nHostSocketPort);
typedef void(WINAPI* CloseSocket_P)(SOCKET sock);
typedef int(WINAPI* SendText_UDP_P)(SOCKET sock, DWORD ulCardIpAddr, int nCardSocketPort, int nCardId, LPCWSTR wsText);
typedef int(WINAPI* StartTTS_UDP_P)(SOCKET sock, DWORD ulCardIpAddr, int nCardSocketPort, int nCardId, LPCWSTR wsText);

// CMFCDemoDlg 对话框
class CMFCDemoDlg : public CDialog
{
// 构造
public:
	CMFCDemoDlg(CWnd* pParent = nullptr);	// 标准构造函数

// 对话框数据
#ifdef AFX_DESIGN_TIME
	enum { IDD = IDD_MFCDEMO_DIALOG };
#endif

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV 支持


// 实现
protected:
	HICON m_hIcon;

	// 生成的消息映射函数
	virtual BOOL OnInitDialog();
	afx_msg void OnSysCommand(UINT nID, LPARAM lParam);
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:
	//SNXT.dll 句柄
	HINSTANCE hDll;

	//网络套接字
	SOCKET sock;

	//SNXT.DLL内的函数地址变量
	GetDllVersion_P GetDllVersion;
	CreateUDPSocket_P CreateUDPSocket;
	CloseSocket_P CloseSocket;
	SendText_UDP_P SendText_UDP;
	StartTTS_UDP_P StartTTS_UDP;

	afx_msg void OnBnClickedFree();
	afx_msg void OnBnClickedLoad();
	afx_msg void OnBnClickedVersion();
	int m_nCardId;
	CString m_sText;
	afx_msg void OnBnClickedDisplay();
	afx_msg void OnBnClickedTts();
	afx_msg void OnDestroy();
	afx_msg void OnBnClickedCreatesocket();
	afx_msg void OnBnClickedClosesocket();
	int m_nCardPort;
	int m_nLocalPort;
	DWORD m_ulHostIp;
	DWORD m_ulCardIp;
};
