//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <System.Classes.hpp>
#include <Vcl.Controls.hpp>
#include <Vcl.StdCtrls.hpp>
#include <Vcl.Forms.hpp>
//SNXT.DLL�ڵĺ���ԭ�Ͷ���
typedef int(WINAPI *GetDllVersion_P)(void);
typedef HANDLE(WINAPI *OpenComPort_P)(wchar_t* wsComPort, int nBaudrate);
typedef void(WINAPI *CloseComPort_P)(HANDLE hComPort);
typedef int(WINAPI *SendText_P)(HANDLE hCommPort, int nCardId, wchar_t* wsText);
typedef int(WINAPI *SendTextA5_P)(HANDLE hCommPort, int nCardId, wchar_t* wsText);
typedef int(WINAPI *StartTTS_P)(HANDLE hCommPort, int nCardId, wchar_t* wsText);

//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
	TEdit *editComPortName;
	TLabel *Label1;
	TButton *btnOpen;
	TButton *btnClose;
	TMemo *Memo1;
	TButton *btnDisplay;
	TButton *btnTTS;
	TButton *btnLoadDll;
	TButton *btnFreeDll;
	TLabel *Label2;
	TEdit *editCardId;
	TButton *btnVersion;
	TButton *btnDisplay_A5;
	void __fastcall btnOpenClick(TObject *Sender);
	void __fastcall btnFreeDllClick(TObject *Sender);
	void __fastcall btnLoadDllClick(TObject *Sender);
	void __fastcall btnCloseClick(TObject *Sender);
	void __fastcall FormDestroy(TObject *Sender);
	void __fastcall btnDisplayClick(TObject *Sender);
	void __fastcall btnTTSClick(TObject *Sender);
	void __fastcall btnVersionClick(TObject *Sender);
	void __fastcall btnDisplay_A5Click(TObject *Sender);
private:	// User declarations
public:		// User declarations
	__fastcall TForm1(TComponent* Owner);

	//SNXT.dll ���
	HINSTANCE hDll;
	//���ھ��
	HANDLE hComPort;

	//SNXT.DLL�ڵĺ�����ַ����
	GetDllVersion_P GetDllVersion;
	OpenComPort_P OpenComPort;
	CloseComPort_P CloseComPort;
	SendText_P SendText;
	StartTTS_P StartTTS;
	SendTextA5_P SendTextA5;
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
#endif
